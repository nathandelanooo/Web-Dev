interface Login {
    void signIn();
}